﻿/*!
 * @brief	数学関係色々。
 */
#include "tkEngine/tkEnginePreCompile.h"
#include "tkEngine/math/tkMath.h"

namespace tkEngine{
}